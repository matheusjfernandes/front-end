import { Component, } from '@angular/core';


@Component({
  selector: 'app-exercicios',
  templateUrl: './exercicios.component.html',
  styleUrls: ['./exercicios.component.css']
})
export class ExerciciosComponent {
  frase: string = 'olá mundo';
  link = "https://www.google.com/url?sa=t&rct=j&q=&esrc=s&source=web&cd=&cad=rja&uact=8&ved=2ahUKEwjswp24n_6BAxXvILkGHVdjAFgQFnoECCcQAQ&url=https%3A%2F%2Fwww.crunchyroll.com%2Fpt-br%2Fseries%2FGRDV0019R%2Fjujutsu-kaisen&usg=AOvVaw3FabIbSoggefWd2W6svBcU&opi=89978449";
  cor = 'blue'
  mudaCor = ()=>{
  if(this.cor == 'black'){
    this.cor = 'blue'
  }else{
    this.cor = 'black'
  }
}
  
texto = '';
setTexto(value:string): void {
  this.texto = value;
}
}
  
  
